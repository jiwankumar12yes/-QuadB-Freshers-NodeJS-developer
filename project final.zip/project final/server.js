import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import router from './public/src/routes/api.js';

dotenv.config();
const __filename = new URL(import.meta.url).pathname;
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3200;

// Use express.urlencoded() for parsing application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));
// Set up the view engine and views directory
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'src')));

app.use('/api', router);
app.get('/', (req, res) => {
    res.send("Please go to this link for project <h3>http://localhost:3000/api/crypto_data<h3>");
});
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
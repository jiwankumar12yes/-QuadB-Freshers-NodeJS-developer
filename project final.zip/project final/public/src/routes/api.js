import express from 'express';
import axios from 'axios';
import dataController from '../controllers/dataController.js';

const router = express.Router();

// Route to get data from the database
router.get('/', async (req, res) => {
    try {
        const response = await axios.get('https://api.wazirx.com/api/v2/tickers');

        console.log('API Response:', response.data);

        if (Array.isArray(response.data)) {
            res.render('index', { data: response.data }); // Pass the data to the view
        } else {
            throw new Error('Invalid response structure: Array expected');
        }
    } catch (error) {
        console.error('Error fetching data from the API:', error.message);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

export default router;

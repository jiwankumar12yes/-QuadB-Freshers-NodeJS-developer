// db.js

import axios from 'axios';
import { createPool } from 'mysql';

const pool = createPool({
    connectionLimit: 10,
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'JiwanRoot',
    database: process.env.DB_NAME || 'Jiwan_QuadB',
});

const fetchAndStoreData = async () => {
    try {
        const response = await axios.get('https://api.wazirx.com/api/v2/tickers');
        const dataToStore = response.data.slice(0, 10).map(item => ({
            name: item.symbol,
            last: item.last,
            buy: item.buy,
            sell: item.sell,
            volume: item.volume,
            base_unit: item.baseAsset,
        }));

        await pool.query('DELETE FROM crypto_data');
        await pool.query('INSERT INTO crypto_data (name, last, buy, sell, volume, base_unit) VALUES ?',
            [dataToStore.map(Object.values)]);

        console.log('Data fetched and stored successfully!');
    } catch (error) {
        console.error('Error fetching or storing data:', error.message);
    }
};

export { pool, fetchAndStoreData };

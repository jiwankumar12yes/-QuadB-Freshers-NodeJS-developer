// dataController.js

import axios from 'axios';

const fetchDataFromAPI = async () => {
    try {
        const response = await axios.get('https://api.wazirx.com/api/v2/tickers');
        const dataToStore = response.data.slice(0, 10).map(item => ({
            name: item.symbol,
            last: item.last,
            buy: item.buy,
            sell: item.sell,
            volume: item.volume,
            base_unit: item.baseAsset,
        }));
        return dataToStore;
    } catch (error) {
        console.error('Error fetching data from the API:', error.message);
        throw error;
    }
};

export default {
    fetchDataFromAPI,
};


// import pkg from 'pg';
// const { Pool } = pkg;


// const pool = new Pool({
//     user: 'root',
//     host: 'localhost',
//     database: 'Jiwan_QuadB',
//     password: 'JiwanRoot',
//     port: 5432,
// });

// const getCryptoData = async (req, res) => {
//     try {
//         const result = await pool.query('SELECT * FROM crypto_data');
//         res.json(result.rows);
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ error: 'Internal Server Error' });
//     }
// };
// export default {
//     getCryptoData,
// };
